# Death rates per unit of electricity production - Data package

This data package contains the data that powers the chart ["Death rates per unit of electricity production"](https://ourworldindata.org/grapher/death-rates-from-energy-production-per-twh?v=1&csvType=full&useColumnShortNames=false) on the Our World in Data website. It was downloaded on November 17, 2024.

## CSV Structure

The high level structure of the CSV file is that each row is an observation for an entity (usually a country or region) and a timepoint (usually a year).

The first two columns in the CSV file are "Entity" and "Code". "Entity" is the name of the entity (e.g. "United States"). "Code" is the OWID internal entity code that we use if the entity is a country or region. For normal countries, this is the same as the [iso alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code of the entity (e.g. "USA") - for non-standard countries like historical countries these are custom codes.

The third column is either "Year" or "Day". If the data is annual, this is "Year" and contains only the year as an integer. If the column is "Day", the column contains a date string in the form "YYYY-MM-DD".

The final column is the data column, which is the time series that powers the chart. If the CSV data is downloaded using the "full data" option, then the column corresponds to the time series below. If the CSV data is downloaded using the "only selected data visible in the chart" option then the data column is transformed depending on the chart type and thus the association with the time series might not be as straightforward.

## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc.. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc..

## About the data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stich together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

## Detailed information about the data


## Deaths per terawatt-hour of energy production
Death rates from energy sources is measured as the number of deaths from air pollution and accidents per terawatt-hour (TWh) of energy production.


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Deaths per TWh energy production – processed by Our World in Data

#### Full citation
Deaths per TWh energy production – processed by Our World in Data. “Deaths per terawatt-hour of energy production” [dataset]. Deaths per TWh energy production [original data].
Source: Deaths per TWh energy production – processed by Our World In Data

### Additional information about this data
Death rates from energy production is measured as the number of deaths by energy source per terawatt-hour (TWh) of electricity production. 

Data on death rates from fossil fuels is sourced from Markandya, A., & Wilkinson, P. (2007).

Data on death rates from solar and wind is sourced from Sovacool et al. (2016) based on a database of accidents from these sources.

We estimate deaths rates for nuclear energy based on the latest death toll figures from Chernobyl and Fukushima as described in our article here: https://ourworldindata.org/what-was-the-death-toll-from-chernobyl-and-fukushima

We estimate death rates from hydropower based on an updated list of historical hydropower accidents, dating back to 1965, sourced primarily from the underlying database included in Sovacool et al. (2016). For more information, see our article: https://ourworldindata.org/safest-sources-of-energy


    